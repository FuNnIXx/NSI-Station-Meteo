# NSI-Station-Meteo
Exercice : https://github.com/msilanus/StationMeteo

**Utilisation :**

-V1.0.0 :

  EXE / main.py
  
-V2.0.0 :

  EXE / interface.py (utiliser le srcipt en presence de ses dependances presentes dans /V2-2.0.0/)

repo : https://github.com/FuNnIXx/NSI-Station-Meteo/tree/main
